#############################
Other information
#############################

Besides the GEMINI `manuscript <http://www.ploscompbiol.org/article/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003153>`_
itself, see this `presentation <http://quinlanlab.org/pdf/Gemini-Quinlan-Stroke-UVA.pdf>`_ for a high-level overview of GEMINI.  

Additionally, this `video <http://www.youtube.com/watch?v=p-UWmDG6yj4&t=0m40s>`_ provides more details about GEMINI's aims and
utility.