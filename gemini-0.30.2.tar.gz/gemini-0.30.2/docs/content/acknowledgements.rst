################
Acknowledgements
################

GEMINI is developed by Uma Paila and Aaron Quinlan in the
`Quinlan laboratory <http://quinlanlab.org/>`_ at the University of Virginia.
Substantial contributions to the design, functionality, and code base have been
made by the following:

- Brad Chapman, HSPH
- Rory Kirchner, HSPH
- Oliver Hofmann, HSPH
- Björn Grüning, University of Freiburg
